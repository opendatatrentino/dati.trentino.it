# -*- coding: utf-8 -*-
#used to simulate the library module used in doctests

